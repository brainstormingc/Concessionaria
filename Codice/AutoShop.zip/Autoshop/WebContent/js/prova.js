function ora(){
	
	window.alert("ciao");
}
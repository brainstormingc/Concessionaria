function resetForm(){
	
	document.modulo.reset();
}